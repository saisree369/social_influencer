package com.practice.socialinfluencerr

interface ExampleInterface {
    fun onSuccessResponse(result: String)
    fun onFailure(error: String)
}