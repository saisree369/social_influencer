package com.practice.socialinfluencer


data class Inf_Profile(
    val age: Int,
    val posts:Int,
    val followers: Int,
    val id: Int,
    val name: String,
    val profile_pic: String
)