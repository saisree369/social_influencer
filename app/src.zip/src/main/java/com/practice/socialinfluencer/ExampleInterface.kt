package com.practice.socialinfluencer

interface ExampleInterface {
    fun onSuccessResponse(result: String)
    fun onFailure(error: String)
}